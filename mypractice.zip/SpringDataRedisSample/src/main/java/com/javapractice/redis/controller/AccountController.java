package com.javapractice.redis.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.javapractice.redis.model.Account;
import com.javapractice.redis.repo.CustomerRepository;

@RestController
public class AccountController {

	@Autowired
	private CustomerRepository customerRepository;

	@RequestMapping("/save")
	public String save() {
		customerRepository.save(new Account(1, "jai", "Prakash"));
		customerRepository.save(new Account(2, "amit", "Sinha"));
		customerRepository.save(new Account(3, "kailash", "Shinde"));
		customerRepository.save(new Account(4, "krishna", "Das"));
		customerRepository.save(new Account(5, "pranav", "Das"));

		return "Done";
	}

	@RequestMapping("/findall")
	public String findAll() {
		String result = "";
		Map<Long, Account> accounts = customerRepository.findAll();

		for (Account account : accounts.values()) {
			result += account.toString() + "<br>";
		}

		return result;
	}

	@RequestMapping("/find")
	public String findById(@RequestParam("id") Long id) {
		String result = "";
		result = customerRepository.find(id).toString();
		return result;
	}

	@RequestMapping(value = "/uppercase")
	public String postCustomer(@RequestParam("id") Long id) {
		Account account = customerRepository.find(id);
		account.setFirstName(account.getFirstName().toUpperCase());
		account.setLastName(account.getLastName().toUpperCase());

		customerRepository.update(account);

		return "Done";
	}

	@RequestMapping("/delete")
	public String deleteById(@RequestParam("id") Long id) {
		customerRepository.delete(id);

		return "Done";
	}
}
