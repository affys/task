package com.javapractice.redis.repo;

import java.util.Map;

import com.javapractice.redis.model.Account;

public interface CustomerRepository {

	void save(Account account);
	Account find(Long id);
	Map<Long, Account> findAll();
	void update(Account account);
	void delete(Long id);
}
